(function($) {
  $(function() {

    // فتح وإغلاق شريط التنقل 
    $('#navbar-toggle').click(function() {
      $('nav ul').slideToggle();
    });

    // تبديل القائمة الجانبية
    $('#navbar-toggle').on('click', function() {
      this.classList.toggle('active');
    });

    // إذا كان هناك قائمة منسدلة، قم بإضافة تبديل للقائمة الفرعية.
    $('nav ul li a:not(:only-child)').click(function(e) {
      var dropdown = $(this).siblings('.navbar-dropdown');
      if (dropdown.is(":visible")) {
        dropdown.hide();
      } else {
        dropdown.show().css('z-index', '1');
        $('.navbar-dropdown').not(dropdown).hide().css('z-index', '0');
      }
      e.stopPropagation();
    });

    // النقر خارج القائمة المنسدلة سيزيل الفئة التابعة لها
    $('html').click(function() {
      $('.navbar-dropdown').hide();
    });
  });
})(jQuery);